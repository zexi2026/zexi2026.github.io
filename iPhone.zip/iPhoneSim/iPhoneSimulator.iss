; ================= 苹果手机模拟器 安装包脚本 =================
; 用 Inno Setup 打开本文件，点 Build -> Compile 即可生成单个 EXE 安装包

#define MyAppName "苹果手机模拟器"
#define MyAppVersion "1.0"
#define MyAppPublisher "Zexi"
#define MyAppExeName "iPhoneSimulator.html"

[Setup]
AppId={{8F3A2B1C-1234-5678-9ABC-DEF012345678}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\iPhoneSimulator
DefaultGroupName=苹果手机模拟器
DisableProgramGroupPage=yes
; 安装程序图标（就是那个iPhone照片）
SetupIconFile=app.ico
; 输出单个EXE
OutputDir=Output
OutputBaseFilename=iPhoneSimulatorSetup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
; 允许中文
ShowLanguageDialog=no

[Languages]
Name: "chinesesimp"; MessagesFile: "compiler:Languages\ChineseSimplified.isl"

[Messages]
WelcomeLabel1=欢迎安装 [name]
WelcomeLabel2=这是一个在电脑上模拟苹果手机(iPhone)的程序。\n\n本向导将引导你完成解包、解压和安装。\n点击“下一步”继续。

[Tasks]
Name: "desktopicon"; Description: "在桌面创建快捷方式(&D)"; GroupDescription: "附加任务:"
Name: "startupicon"; Description: "开机自动运行(&S)"; GroupDescription: "附加任务:"

[Files]
; 把模拟器文件解压到安装目录
Source: "files\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs

[Icons]
; 开始菜单
Name: "{group}\苹果手机模拟器"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\卸载苹果手机模拟器"; Filename: "{uninstallexe}"
; 桌面快捷方式（按勾选）
Name: "{userdesktop}\苹果手机模拟器"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Registry]
; 开机自启动（按勾选）
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; \
  ValueType: string; ValueName: "iPhoneSimulator"; ValueData: """{app}\{#MyAppExeName}"""; \
  Flags: uninsdeletevalue; Tasks: startupicon

[Run]
; 安装完成后，可选立即启动
Filename: "{app}\{#MyAppExeName}"; Description: "立即启动苹果手机模拟器(&L)"; Flags: nowait postinstall skipifsilent
