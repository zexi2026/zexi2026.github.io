@echo off
chcp 65001 >nul
title 苹果手机模拟器 安装程序
color 0B
cls

echo.
echo ============================================
echo        欢迎安装 苹果手机模拟器
echo ============================================
echo.
echo   这是一个在电脑上模拟苹果手机(iPhone)的程序
echo.
pause
cls

echo.
echo ============================================
echo            软件用户协议
echo ============================================
echo.
echo   1. 本程序仅供学习和个人娱乐使用
echo   2. 你可以自己改代码，添加更多手机App
echo   3. 请勿用于非法用途
echo.
echo   同意协议才能继续安装。
echo.
set /p agree=是否同意？(Y=继续 / N=退出): 
if /i not "%agree%"=="Y" (
    echo.
    echo 你没有同意协议，安装已取消。
    pause
    exit
)
cls

echo.
echo ============================================
echo            选择安装位置
echo ============================================
echo.
set "instdir=C:\Program Files\iPhoneSimulator"
echo   默认安装到: %instdir%
echo.
set /p custom=要改位置吗？直接回车用默认，或输入新路径: 
if not "%custom%"=="" set "instdir=%custom%"
echo.
echo   将安装到: %instdir%
echo.
pause
cls

echo.
echo ============================================
echo            正在安装（解压文件）
echo ============================================
echo.
mkdir "%instdir%" 2>nul
echo [1/3] 正在复制程序文件...
xcopy "%~dp0files\*" "%instdir%\" /E /I /Y /Q >nul
echo [2/3] 文件解压完成
echo [3/3] 正在设置...
echo.
echo   安装完成！
echo.
pause
cls

echo.
echo ============================================
echo            附加选项
echo ============================================
echo.
set /p desk=要在桌面创建快捷方式吗？(Y/N): 
if /i "%desk%"=="Y" (
    powershell "$s=(New-Object -COM WScript.Shell).CreateShortcut('%userprofile%\Desktop\苹果手机模拟器.lnk');$s.TargetPath='%instdir%\iPhoneSimulator.html';$s.Save()"
    echo   桌面快捷方式已创建
)
echo.
set /p boot=要开机自动启动吗？(Y/N): 
if /i "%boot%"=="Y" (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v iPhoneSimulator /t REG_SZ /d "\"%instdir%\iPhoneSimulator.html\"" /f >nul
    echo   已设为开机自启
)
echo.
echo ============================================
echo              安装完成！
echo ============================================
echo.
echo   程序位置: %instdir%\iPhoneSimulator.html
echo   双击它就能玩苹果手机啦！
echo.
set /p now=要现在打开吗？(Y/N): 
if /i "%now%"=="Y" start "" "%instdir%\iPhoneSimulator.html"
echo.
pause
